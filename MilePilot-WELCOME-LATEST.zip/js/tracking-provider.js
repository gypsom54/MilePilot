/**
 * MP-039 — Tracking provider abstraction: web | native
 * Web: existing navigator.geolocation (wired from index.html)
 * Native: Capacitor Geolocation (+ background foundation for device testing)
 */
(function (global) {
  'use strict';

  const NATIVE_LOCATION_WHEN_IN_USE =
    'MilePilot uses location to record your business journeys while you are working.';
  const NATIVE_LOCATION_ALWAYS =
    'MilePilot uses background location so your mileage can continue recording when your phone is locked.';

  let deps = null;
  let nativeWatchId = null;
  let backgroundActive = false;
  let logBuffer = [];

  function log(msg, data) {
    const entry = { t: new Date().toISOString(), msg: msg, data: data || null };
    logBuffer.push(entry);
    if (logBuffer.length > 200) logBuffer.shift();
    try {
      console.log('[MPTrackingProvider]', msg, data || '');
    } catch (e) {}
  }

  function getMode() {
    if (global.MPPlatform && global.MPPlatform.getRuntimeMode) {
      return global.MPPlatform.getRuntimeMode();
    }
    return 'browser';
  }

  function isNative() {
    return getMode() === 'native';
  }

  function isWebShell() {
    return !isNative();
  }

  function getGeolocationPlugin() {
    try {
      if (global.Capacitor && global.Capacitor.Plugins && global.Capacitor.Plugins.Geolocation) {
        return global.Capacitor.Plugins.Geolocation;
      }
    } catch (e) {}
    return null;
  }

  function capToBrowserPosition(capPos) {
    if (!capPos || !capPos.coords) return null;
    return {
      coords: {
        latitude: capPos.coords.latitude,
        longitude: capPos.coords.longitude,
        accuracy: capPos.coords.accuracy,
        altitude: capPos.coords.altitude,
        altitudeAccuracy: capPos.coords.altitudeAccuracy,
        heading: capPos.coords.heading,
        speed: capPos.coords.speed,
      },
      timestamp: capPos.timestamp || Date.now(),
    };
  }

  function init(hookDeps) {
    deps = hookDeps || {};
    log('init', { mode: getMode() });
  }

  async function queryPermissionStatus() {
    if (!isNative()) {
      if (typeof deps.queryGeoPermission === 'function') return deps.queryGeoPermission();
      return 'unknown';
    }
    const Geo = getGeolocationPlugin();
    if (!Geo || !Geo.checkPermissions) return 'unknown';
    try {
      const r = await Geo.checkPermissions();
      const loc = r.location || r.coarseLocation || 'prompt';
      if (loc === 'granted') return 'granted';
      if (loc === 'denied') return 'denied';
      return 'prompt';
    } catch (e) {
      log('checkPermissions failed', e.message);
      return 'unknown';
    }
  }

  async function requestPermissions() {
    if (!isNative()) return queryPermissionStatus();
    const Geo = getGeolocationPlugin();
    if (!Geo || !Geo.requestPermissions) return 'unavailable';
    try {
      const r = await Geo.requestPermissions({ permissions: ['location', 'coarseLocation'] });
      const loc = r.location || r.coarseLocation || 'denied';
      log('requestPermissions', loc);
      return loc === 'granted' ? 'granted' : loc;
    } catch (e) {
      log('requestPermissions error', e.message);
      return 'denied';
    }
  }

  async function startBackgroundFoundation() {
    if (!isNative() || !isShiftActive()) return false;
    if (backgroundActive) return true;
    // Foundation for @capacitor-community/background-geolocation — enable on device after plugin install
    log('background foundation: native shift active — use device logs to verify when plugin added');
    backgroundActive = true;
    return true;
  }

  function stopBackgroundFoundation() {
    backgroundActive = false;
  }

  function isShiftActive() {
    if (typeof deps.isShiftTracking === 'function') return deps.isShiftTracking();
    if (global.MPTracking && global.MPTracking.isActive) return global.MPTracking.isActive();
    return false;
  }

  async function startNativeWatch() {
    const Geo = getGeolocationPlugin();
    if (!Geo || !Geo.watchPosition) {
      log('Geolocation plugin unavailable');
      return false;
    }
    if (nativeWatchId !== null) return true;
    try {
      nativeWatchId = await Geo.watchPosition(
        {
          enableHighAccuracy: true,
          timeout: 30000,
          maximumAge: 0,
        },
        function (position, err) {
          if (err) {
            log('watchPosition error', err.message || String(err));
            return;
          }
          if (deps.handlePos && position) {
            const p = capToBrowserPosition(position);
            if (p) deps.handlePos(p);
          }
        }
      );
      log('watch started', { id: nativeWatchId });
      await startBackgroundFoundation();
      return true;
    } catch (e) {
      log('startNativeWatch failed', e.message);
      nativeWatchId = null;
      return false;
    }
  }

  function stopNativeWatch() {
    const Geo = getGeolocationPlugin();
    if (Geo && Geo.clearWatch && nativeWatchId !== null) {
      try {
        Geo.clearWatch({ id: nativeWatchId });
      } catch (e) {
        log('clearWatch error', e.message);
      }
    }
    nativeWatchId = null;
    stopBackgroundFoundation();
  }

  /**
   * Native replacement for enableTrackingGps — called from index.html when isNative()
   */
  async function enableTracking(fromUserGesture) {
    if (!deps) return false;
    if (!isNative()) return false;

    if (deps.updateGpsUi) deps.updateGpsUi('Finding GPS…');
    if (deps.showStatus) deps.showStatus('Finding GPS…');

    const perm = fromUserGesture ? await requestPermissions() : await queryPermissionStatus();
    if (perm !== 'granted' && fromUserGesture) {
      const retry = await requestPermissions();
      if (retry !== 'granted') {
        if (deps.updateGpsUi) deps.updateGpsUi(global.trackingErrorMessage ? global.trackingErrorMessage('denied') : 'Location denied');
        if (deps.hideStatus) deps.hideStatus();
        return false;
      }
    } else if (perm !== 'granted') {
      if (deps.updateGpsUi) deps.updateGpsUi('Enable location so AutoPilot can start recording.');
      if (deps.hideStatus) deps.hideStatus();
      return false;
    }

    stopNativeWatch();
    const ok = await startNativeWatch();
    if (ok) {
      try {
        localStorage.setItem('mp_location_choice', 'granted');
        localStorage.setItem('mp_onboard_flag_location', 'true');
      } catch (e) {}
      if (global.gpsLocked !== undefined) global.gpsLocked = true;
      if (deps.updateGpsUi) deps.updateGpsUi(null);
      if (deps.hideStatus) deps.hideStatus();
      log('enableTracking ok');
      return true;
    }
    if (deps.updateGpsUi) deps.updateGpsUi('GPS unavailable');
    if (deps.hideStatus) deps.hideStatus();
    return false;
  }

  function stopTracking() {
    if (!isNative()) return;
    stopNativeWatch();
  }

  function getNativePermissionCopy() {
    return { whenInUse: NATIVE_LOCATION_WHEN_IN_USE, background: NATIVE_LOCATION_ALWAYS };
  }

  function getLogs() {
    return logBuffer.slice();
  }

  function getHealthBackground() {
    if (isWebShell()) {
      return {
        state: 'ok',
        status: getMode() === 'pwa' ? 'PWA mode' : 'Browser mode',
        hint: MPPlatform.getBackgroundTrackingNote(),
        action: '',
      };
    }
    const perm = localStorage.getItem('mp_location_choice');
    if (perm === 'granted') {
      return {
        state: backgroundActive ? 'ok' : 'warn',
        status: backgroundActive ? 'Testing' : 'Not confirmed',
        hint: backgroundActive
          ? 'Background location foundation active — verify on a real drive.'
          : 'Start a shift to begin native GPS testing.',
        action: perm === 'granted' ? '' : 'gps',
      };
    }
    return {
      state: 'warn',
      status: 'Needs location',
      hint: NATIVE_LOCATION_WHEN_IN_USE,
      action: 'gps',
    };
  }

  global.MPTrackingProvider = {
    init: init,
    getMode: getMode,
    isNative: isNative,
    isWebShell: isWebShell,
    enableTracking: enableTracking,
    stopTracking: stopTracking,
    queryPermissionStatus: queryPermissionStatus,
    requestPermissions: requestPermissions,
    getNativePermissionCopy: getNativePermissionCopy,
    getHealthBackground: getHealthBackground,
    getLogs: getLogs,
    NATIVE_LOCATION_WHEN_IN_USE: NATIVE_LOCATION_WHEN_IN_USE,
    NATIVE_LOCATION_ALWAYS: NATIVE_LOCATION_ALWAYS,
  };
})(typeof window !== 'undefined' ? window : global);
