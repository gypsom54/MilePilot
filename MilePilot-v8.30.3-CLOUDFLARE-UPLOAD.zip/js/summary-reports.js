/**
 * VITAL — BUSINESS CRITICAL (MP-044)
 * Automatic report scheduling and delivery. Do not modify without explicit approval.
 * Contract: scripts/reports-contract.json · CI: production-guard.yml
 * See docs/CRITICAL_FILES.md and docs/PRODUCTION_MONITORING_PLAN.md
 *
 * MilePilot Automatic Summary Reports
 * Works alongside the user's chosen report frequency — summaries stack, not replace.
 */
(function (global) {
  'use strict';

  const SENT_PREFIX = 'mp_auto_report_sent_';
  const PENDING_REPORT_KEY = 'mp_pending_report';
  const LAST_EMAIL_RESULT_KEY = 'mp_last_email_result';
  const LOG_PREFIX = '[MilePilot Reports]';

  function reportLog(msg, data) {
    if (typeof console !== 'undefined' && console.log) {
      console.log(LOG_PREFIX, msg, data !== undefined ? data : '');
    }
  }

  function saveLastEmailResult(result) {
    try {
      localStorage.setItem(
        LAST_EMAIL_RESULT_KEY,
        JSON.stringify(Object.assign({ t: Date.now() }, result || {}))
      );
    } catch (e) {}
  }

  function getLastEmailResult() {
    try {
      return JSON.parse(localStorage.getItem(LAST_EMAIL_RESULT_KEY) || 'null');
    } catch (e) {
      return null;
    }
  }

  function persistPendingReport(type, fireAt, shiftEndedAt) {
    try {
      localStorage.setItem(
        PENDING_REPORT_KEY,
        JSON.stringify({
          type: type,
          fireAt: fireAt,
          shiftEndedAt: shiftEndedAt,
          createdAt: Date.now(),
        })
      );
      reportLog('Report email scheduled (persisted)', {
        type: type,
        fireAt: new Date(fireAt).toISOString(),
      });
    } catch (e) {
      reportLog('Failed to persist pending report', { error: String(e) });
    }
  }

  function clearPendingReport() {
    localStorage.removeItem(PENDING_REPORT_KEY);
  }

  function loadPendingReport() {
    try {
      const raw = localStorage.getItem(PENDING_REPORT_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch (e) {
      return null;
    }
  }

  async function checkPendingReports(deps) {
    const pending = loadPendingReport();
    if (!pending) return null;
    if (Date.now() < pending.fireAt) return { waiting: true, pending: pending };
    reportLog('Pending report due — sending', { type: pending.type });
    clearPendingReport();
    const result = await sendAutomaticReport(deps, pending.type, new Date());
    return result;
  }

  const SCHEDULE = {
    dailyAfterShiftHours: 1,
    weeklyPrimary: { day: 0, hour: 18, minute: 0, windowMin: 45 },
    weeklySummary: { day: 0, hour: 23, minute: 59, windowMin: 35 },
    monthlyPrimary: { hour: 23, minute: 59, windowMin: 35 },
    monthlySummary: { hour: 23, minute: 59, windowMin: 35 },
  };

  function pad2(n) {
    return String(n).padStart(2, '0');
  }

  function weekKey(d) {
    const x = new Date(d);
    x.setHours(0, 0, 0, 0);
    x.setDate(x.getDate() - ((x.getDay() + 6) % 7));
    return x.toISOString().slice(0, 10);
  }

  function monthKey(d) {
    return d.getFullYear() + '-' + pad2(d.getMonth() + 1);
  }

  function dayKey(d) {
    return d.toISOString().slice(0, 10);
  }

  function wasSent(type, key) {
    try {
      return global.localStorage.getItem(SENT_PREFIX + type + '_' + key) === '1';
    } catch (e) {
      return false;
    }
  }

  function markSent(type, key) {
    try {
      global.localStorage.setItem(SENT_PREFIX + type + '_' + key, '1');
    } catch (e) {}
  }

  function isLastDayOfMonth(d) {
    const last = new Date(d.getFullYear(), d.getMonth() + 1, 0);
    return d.getDate() === last.getDate();
  }

  function minutesOfDay(d) {
    return d.getHours() * 60 + d.getMinutes();
  }

  function inTimeWindow(now, hour, minute, windowMin) {
    const target = hour * 60 + minute;
    const current = minutesOfDay(now);
    return current >= target - windowMin && current <= target + 15;
  }

  function isSundaySlot(now, slot) {
    if (now.getDay() !== slot.day) {
      if (now.getDay() === (slot.day + 1) % 7 && minutesOfDay(now) < 30) return true;
      return false;
    }
    return inTimeWindow(now, slot.hour, slot.minute, slot.windowMin);
  }

  function isMonthlySlot(now, slot) {
    if (isLastDayOfMonth(now) && inTimeWindow(now, slot.hour, slot.minute, slot.windowMin)) return true;
    if (now.getDate() === 1 && minutesOfDay(now) < 30) return true;
    return false;
  }

  function getDueReportTypes(frequency, now) {
    const due = [];
    if (!frequency || frequency === 'off') return due;

    if (frequency === 'daily') {
      if (isSundaySlot(now, SCHEDULE.weeklySummary)) due.push('WeeklySummary');
      if (isMonthlySlot(now, SCHEDULE.monthlySummary)) due.push('MonthlySummary');
    } else if (frequency === 'weekly') {
      if (isSundaySlot(now, SCHEDULE.weeklyPrimary)) due.push('Weekly');
      if (isMonthlySlot(now, SCHEDULE.monthlySummary)) due.push('MonthlySummary');
    } else if (frequency === 'monthly') {
      if (isMonthlySlot(now, SCHEDULE.monthlyPrimary)) due.push('Monthly');
    }
    return due;
  }

  function dedupeKey(type, now) {
    if (type === 'Daily') return dayKey(now);
    if (type === 'Weekly' || type === 'WeeklySummary') return weekKey(now);
    if (type === 'Monthly' || type === 'MonthlySummary') return monthKey(now);
    return dayKey(now);
  }

  function tripToShiftRow(trip) {
    return {
      miles: trip.miles,
      seconds: trip.seconds,
      hmrc: trip.hmrc,
      vehicle: trip.vehicle,
      startISO: trip.startISO,
      endISO: trip.endISO,
      route: trip.route || trip.routePoints || [],
      waitingSeconds: trip.waitingSeconds || 0,
    };
  }

  function collectBusinessJourneys(deps) {
    const trips = typeof deps.getTrips === 'function' ? deps.getTrips() : [];
    const business = trips.filter(function (t) {
      return t.status === 'business';
    });
    const pending = trips.filter(function (t) {
      return t.status === 'pending';
    });
    const shifts = typeof deps.getShifts === 'function' ? deps.getShifts() : [];
    const tripShiftIds = new Set(
      business.map(function (t) {
        return t.shiftId;
      }).filter(Boolean)
    );
    const unmigratedShifts = shifts.filter(function (s) {
      return !tripShiftIds.has(s.id) && (Number(s.miles) || 0) >= 0.01;
    });
    const list = business.map(tripToShiftRow).concat(unmigratedShifts);

    return {
      list: list,
      excludedPending: pending.length,
      pendingNotice:
        pending.length > 0
          ? pending.length +
            ' pending journey' +
            (pending.length > 1 ? 's' : '') +
            ' excluded from this report.'
          : null,
    };
  }

  function journeysInRange(list, start, end) {
    const s = start.getTime();
    const e = end.getTime();
    return list.filter(function (j) {
      const t = new Date(j.startISO).getTime();
      return t >= s && t < e;
    });
  }

  function sumJourneys(list) {
    return {
      mi: list.reduce(function (a, b) {
        return a + Number(b.miles || 0);
      }, 0),
      sec: list.reduce(function (a, b) {
        return a + Number(b.seconds || 0);
      }, 0),
      hmrc: list.reduce(function (a, b) {
        return a + Number(b.hmrc || 0);
      }, 0),
      journeys: list.length,
      list: list,
    };
  }

  function weekRangeContaining(refDate) {
    const end = new Date(refDate);
    end.setHours(23, 59, 59, 999);
    const start = new Date(end);
    start.setHours(0, 0, 0, 0);
    start.setDate(start.getDate() - ((start.getDay() + 6) % 7));
    const rangeEnd = new Date(start);
    rangeEnd.setDate(rangeEnd.getDate() + 7);
    return { start: start, end: rangeEnd };
  }

  function previousWeekRange(refDate) {
    const cur = weekRangeContaining(refDate);
    const end = new Date(cur.start);
    const start = new Date(end);
    start.setDate(start.getDate() - 7);
    return { start: start, end: end };
  }

  function monthRangeContaining(refDate) {
    const d = refDate || new Date();
    const start = new Date(d.getFullYear(), d.getMonth(), 1);
    const end = new Date(d.getFullYear(), d.getMonth() + 1, 1);
    return { start: start, end: end };
  }

  function previousMonthRange(refDate) {
    const d = refDate || new Date();
    const start = new Date(d.getFullYear(), d.getMonth() - 1, 1);
    const end = new Date(d.getFullYear(), d.getMonth(), 1);
    return { start: start, end: end };
  }

  function buildDailyBreakdown(list) {
    const map = {};
    list.forEach(function (j) {
      const d = new Date(j.startISO);
      const key = d.toISOString().slice(0, 10);
      if (!map[key]) {
        map[key] = {
          date: d.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' }),
          iso: key,
          miles: 0,
          seconds: 0,
          journeys: 0,
        };
      }
      map[key].miles += Number(j.miles || 0);
      map[key].seconds += Number(j.seconds || 0);
      map[key].journeys += 1;
    });
    return Object.keys(map)
      .sort()
      .map(function (k) {
        return map[k];
      });
  }

  function buildWeeklyBreakdown(list, monthStart) {
    const weeks = {};
    list.forEach(function (j) {
      const d = new Date(j.startISO);
      const wk = weekKey(d);
      if (!weeks[wk]) {
        weeks[wk] = { week: 'Week of ' + new Date(wk).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }), label: '', miles: 0, seconds: 0, journeys: 0 };
      }
      weeks[wk].miles += Number(j.miles || 0);
      weeks[wk].seconds += Number(j.seconds || 0);
      weeks[wk].journeys += 1;
    });
    return Object.keys(weeks)
      .sort()
      .map(function (k) {
        const row = weeks[k];
        row.label = row.week;
        return row;
      });
  }

  function busiestDayLabel(list) {
    const map = {};
    list.forEach(function (j) {
      const k = new Date(j.startISO).toLocaleDateString('en-GB', { weekday: 'long' });
      map[k] = (map[k] || 0) + Number(j.miles || 0);
    });
    let best = null;
    let bestMi = 0;
    Object.keys(map).forEach(function (k) {
      if (map[k] > bestMi) {
        bestMi = map[k];
        best = k;
      }
    });
    return best;
  }

  function longestJourney(list) {
    if (!list.length) return null;
    return list.reduce(function (a, b) {
      return Number(b.miles || 0) > Number(a.miles || 0) ? b : a;
    });
  }

  function buildWeeklySummaryPayload(deps, now) {
    const collected = collectBusinessJourneys(deps);
    const range = weekRangeContaining(now || new Date());
    const prev = previousWeekRange(now || new Date());
    const list = journeysInRange(collected.list, range.start, range.end);
    const prevList = journeysInRange(collected.list, prev.start, prev.end);
    const totals = sumJourneys(list);
    const prevTotals = sumJourneys(prevList);
    const label =
      'Week ending ' +
      new Date(range.end.getTime() - 86400000).toLocaleDateString('en-GB', {
        weekday: 'long',
        day: 'numeric',
        month: 'long',
        year: 'numeric',
      });

    return {
      email: deps.getEmail(),
      driver: deps.getDriver(),
      period: 'WeeklySummary',
      periodLabel: label,
      totals: { miles: totals.mi, time: deps.fmt(totals.sec), hmrc: totals.hmrc },
      previousWeek: {
        miles: prevTotals.mi,
        seconds: prevTotals.sec,
        hmrc: prevTotals.hmrc,
        journeys: prevTotals.journeys,
      },
      shifts: list,
      dailyBreakdown: buildDailyBreakdown(list),
      hmrcRate: deps.getHmrcRate(),
      excludedPending: collected.excludedPending,
      pendingNotice: collected.pendingNotice,
      reportKind: 'summary',
    };
  }

  function buildMonthlySummaryPayload(deps, now) {
    const collected = collectBusinessJourneys(deps);
    const range = monthRangeContaining(now);
    const prev = previousMonthRange(now);
    const list = journeysInRange(collected.list, range.start, range.end);
    const prevList = journeysInRange(collected.list, prev.start, prev.end);
    const totals = sumJourneys(list);
    const prevTotals = sumJourneys(prevList);
    const workingDays = new Set(
      list.map(function (j) {
        return new Date(j.startISO).toDateString();
      })
    ).size;
    const longest = longestJourney(list);
    const label = range.start.toLocaleDateString('en-GB', { month: 'long', year: 'numeric' });

    return {
      email: deps.getEmail(),
      driver: deps.getDriver(),
      period: 'MonthlySummary',
      periodLabel: label,
      totals: { miles: totals.mi, time: deps.fmt(totals.sec), hmrc: totals.hmrc },
      previousPeriod: {
        miles: prevTotals.mi,
        seconds: prevTotals.sec,
        hmrc: prevTotals.hmrc,
        journeys: prevTotals.journeys,
      },
      shifts: list,
      weeklyBreakdown: buildWeeklyBreakdown(list, range.start),
      avgMilesPerDay: workingDays ? totals.mi / workingDays : 0,
      mostActiveDay: busiestDayLabel(list),
      hmrcRate: deps.getHmrcRate(),
      excludedPending: collected.excludedPending,
      pendingNotice: collected.pendingNotice,
      reportKind: 'summary',
    };
  }

  function buildStandardPayload(deps, periodType, now) {
    const collected = collectBusinessJourneys(deps);
    let range;
    let prevRange;
    let apiPeriod;
    if (periodType === 'Weekly') {
      range = weekRangeContaining(now);
      prevRange = previousWeekRange(now);
      apiPeriod = 'Weekly';
    } else if (periodType === 'Monthly') {
      range = monthRangeContaining(now);
      prevRange = previousMonthRange(now);
      apiPeriod = 'Monthly';
    } else {
      range = { start: new Date(now), end: new Date(now) };
      range.start.setHours(0, 0, 0, 0);
      range.end = new Date(range.start);
      range.end.setDate(range.end.getDate() + 1);
      prevRange = { start: new Date(range.start), end: new Date(range.start) };
      prevRange.start.setDate(prevRange.start.getDate() - 1);
      apiPeriod = 'Daily';
    }
    const list = journeysInRange(collected.list, range.start, range.end);
    const prevList = journeysInRange(collected.list, prevRange.start, prevRange.end);
    const totals = sumJourneys(list);
    const prevTotals = sumJourneys(prevList);

    return {
      email: deps.getEmail(),
      driver: deps.getDriver(),
      period: apiPeriod,
      totals: { miles: totals.mi, time: deps.fmt(totals.sec), hmrc: totals.hmrc },
      previousPeriod: { miles: prevTotals.mi, seconds: prevTotals.sec, hmrc: prevTotals.hmrc, journeys: prevTotals.journeys },
      previousWeek: { miles: prevTotals.mi, seconds: prevTotals.sec, hmrc: prevTotals.hmrc, journeys: prevTotals.journeys },
      weekShifts: list,
      shifts: list,
      hmrcRate: deps.getHmrcRate(),
      excludedPending: collected.excludedPending,
      pendingNotice: collected.pendingNotice,
    };
  }

  function buildPayload(deps, type, now) {
    if (type === 'WeeklySummary') return buildWeeklySummaryPayload(deps, now);
    if (type === 'MonthlySummary') return buildMonthlySummaryPayload(deps, now);
    return buildStandardPayload(deps, type, now);
  }

  async function sendAutomaticReport(deps, type, now) {
    const key = dedupeKey(type, now || new Date());
    if (wasSent(type, key)) {
      const skip = { skipped: true, reason: 'already_sent' };
      reportLog('Email skipped — already sent', { type: type, key: key });
      saveLastEmailResult(skip);
      return skip;
    }

    const email = deps.getEmail();
    if (!email) {
      const skip = { skipped: true, reason: 'no_email' };
      reportLog('Email skipped — no email on file', { type: type });
      saveLastEmailResult(skip);
      return skip;
    }

    const payload = buildPayload(deps, type, now);
    if (!payload.shifts.length && type !== 'WeeklySummary' && type !== 'MonthlySummary') {
      const skip = { skipped: true, reason: 'no_data' };
      reportLog('Email skipped — no shift data', { type: type });
      saveLastEmailResult(skip);
      return skip;
    }

    reportLog('Sending automatic report email', { type: type, email: email, journeys: payload.shifts.length });

    try {
      const result = await deps.apiPost('/reports/send', payload);
      if (result && result.res && result.res.ok && result.data && result.data.sent) {
        markSent(type, key);
        if (typeof deps.onSent === 'function') deps.onSent(type, payload);
        const ok = { sent: true, type: type, messageId: result.data.messageId || null };
        reportLog('Email sent successfully', ok);
        saveLastEmailResult(ok);
        return ok;
      }
      const fail = {
        skipped: true,
        reason: 'send_failed',
        detail: result && result.data ? result.data : result,
      };
      reportLog('Email send failed — API rejected', fail);
      saveLastEmailResult(fail);
      return fail;
    } catch (e) {
      const err = { skipped: true, reason: 'error', detail: String(e && e.message ? e.message : e) };
      reportLog('Email send failed — exception', err);
      saveLastEmailResult(err);
      return err;
    }
  }

  async function checkScheduledReports(deps) {
    const pendingResult = await checkPendingReports(deps);
    if (pendingResult && pendingResult.sent) {
      return [pendingResult];
    }

    const frequency = deps.getFrequency();
    if (!frequency || frequency === 'off') return [];
    if (!deps.getEmail()) return [];

    const now = new Date();
    const types = getDueReportTypes(frequency, now);
    const results = [];
    for (let i = 0; i < types.length; i++) {
      results.push(await sendAutomaticReport(deps, types[i], now));
    }
    return results;
  }

  async function sendShiftCompletionEmail(deps, shift, endReason) {
    const email = deps.getEmail();
    if (!email) {
      const skip = { skipped: true, reason: 'no_email' };
      reportLog('Shift completion email skipped — no email', { endReason: endReason });
      saveLastEmailResult(skip);
      return skip;
    }

    const frequency = deps.getFrequency();
    if (!frequency || frequency === 'off') {
      const skip = { skipped: true, reason: 'reports_off' };
      reportLog('Shift completion email skipped — reports off', { endReason: endReason });
      saveLastEmailResult(skip);
      return skip;
    }

    const sentKey = 'shift_completion_' + (shift && shift.id ? shift.id : Date.now());
    if (localStorage.getItem(SENT_PREFIX + sentKey) === '1') {
      return { skipped: true, reason: 'already_sent' };
    }

    const now = shift && shift.endISO ? new Date(shift.endISO) : new Date();
    const payload = buildStandardPayload(deps, 'Daily', now);
    if (!payload.shifts.length) {
      const skip = { skipped: true, reason: 'no_data' };
      reportLog('Shift completion email skipped — no journeys in payload', { shiftId: shift && shift.id });
      saveLastEmailResult(skip);
      return skip;
    }

    reportLog('Sending shift completion email', {
      shiftId: shift && shift.id,
      endReason: endReason,
      email: email,
      journeys: payload.shifts.length,
    });

    try {
      const result = await deps.apiPost('/reports/send', payload);
      if (result && result.res && result.res.ok && result.data && result.data.sent) {
        localStorage.setItem(SENT_PREFIX + sentKey, '1');
        if (typeof deps.onSent === 'function') deps.onSent('Daily', payload);
        const ok = { sent: true, type: 'ShiftCompletion', messageId: result.data.messageId || null };
        reportLog('Shift completion email sent', ok);
        saveLastEmailResult(ok);
        return ok;
      }
      const fail = {
        skipped: true,
        reason: 'send_failed',
        detail: result && result.data ? result.data : result,
      };
      reportLog('Shift completion email failed — API rejected', fail);
      saveLastEmailResult(fail);
      return fail;
    } catch (e) {
      const err = { skipped: true, reason: 'error', detail: String(e && e.message ? e.message : e) };
      reportLog('Shift completion email failed — exception', err);
      saveLastEmailResult(err);
      return err;
    }
  }

  async function onShiftEnded(deps, shift, endReason) {
    reportLog('Shift ended — starting email workflow', {
      shiftId: shift && shift.id,
      endReason: endReason || 'manual',
    });
    const immediate = await sendShiftCompletionEmail(deps, shift, endReason || 'manual');
    if (shift && shift.endISO && deps.getFrequency() === 'daily') {
      scheduleDailyAfterShift(deps, shift.endISO);
    }
    return immediate;
  }

  function scheduleDailyAfterShift(deps, shiftEndedAt) {
    const frequency = deps.getFrequency();
    if (frequency !== 'daily') {
      reportLog('Post-shift email not scheduled — frequency is not daily', { frequency: frequency });
      return null;
    }
    const email = deps.getEmail();
    if (!email) {
      reportLog('Post-shift email not scheduled — no email', {});
      return null;
    }

    const delayMs = SCHEDULE.dailyAfterShiftHours * 60 * 60 * 1000;
    const fireAt = new Date(shiftEndedAt).getTime() + delayMs;
    const wait = Math.max(0, fireAt - Date.now());

    persistPendingReport('Daily', fireAt, shiftEndedAt);

    return setTimeout(async function () {
      const now = new Date();
      const key = dedupeKey('Daily', now);
      if (wasSent('Daily', key)) return;
      clearPendingReport();
      await sendAutomaticReport(deps, 'Daily', now);
    }, wait);
  }

  function getScheduleDescription(frequency) {
    if (frequency === 'daily') {
      return "Daily reports after each shift, plus a Weekly Summary every Sunday at 11:59pm and a Monthly Summary on the last day of each month.";
    }
    if (frequency === 'weekly') {
      return "Weekly report every Sunday, plus a Monthly Summary on the last day of each month at 11:59pm.";
    }
    if (frequency === 'monthly') {
      return "Monthly report on the last day of each month at 11:59pm.";
    }
    return '';
  }

  let deps = null;

  function init(dependencies) {
    deps = dependencies;
  }

  function requireDeps() {
    if (!deps) throw new Error('MPSummaryReports.init() must be called first');
    return deps;
  }

  global.MPSummaryReports = {
    SCHEDULE: SCHEDULE,
    init: init,
    getDueReportTypes: getDueReportTypes,
    getScheduleDescription: getScheduleDescription,
    buildWeeklySummaryPayload: function (now) {
      return buildWeeklySummaryPayload(requireDeps(), now);
    },
    buildMonthlySummaryPayload: function (now) {
      return buildMonthlySummaryPayload(requireDeps(), now);
    },
    buildPayload: function (type, now) {
      return buildPayload(requireDeps(), type, now);
    },
    sendAutomaticReport: function (type, now) {
      return sendAutomaticReport(requireDeps(), type, now);
    },
    checkScheduledReports: function () {
      return checkScheduledReports(requireDeps());
    },
    scheduleDailyAfterShift: function (shiftEndedAt) {
      return scheduleDailyAfterShift(requireDeps(), shiftEndedAt);
    },
    onShiftEnded: function (shift, endReason) {
      return onShiftEnded(requireDeps(), shift, endReason);
    },
    sendShiftCompletionEmail: function (shift, endReason) {
      return sendShiftCompletionEmail(requireDeps(), shift, endReason);
    },
    getLastEmailResult: getLastEmailResult,
    getPendingReport: loadPendingReport,
    checkPendingReports: function () {
      return checkPendingReports(requireDeps());
    },
    wasSent: wasSent,
    markSent: markSent,
  };
})(typeof window !== 'undefined' ? window : globalThis);
