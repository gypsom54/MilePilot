@echo off
cd /d "%~dp0"
wscript.exe "%~dp0OPEN-WEBSITE.vbs"
