MilePilot PDF Test Pack — MP-012-pdf-v7
========================================

DOWNLOAD ZIP
------------
https://github.com/gypsom54/MilePilot/raw/cursor/mp-012-pdf-layout-fix-ae00/MilePilot-PDF-TEST-MP012-v7.zip

WHAT'S NEW IN v7
----------------
- Premium cover page (driver, date, quote, HMRC, QR verify)
- Magazine hero statistic — enormous miles number
- Personalised praise ("Great work today, Jonathan")
- Vertical journey timeline with route sparkline
- Weekly dashboard + 7-day bar chart (screenshot-worthy)
- MilePilot AI coach with advisory insights
- Dedicated Accountant Copy page
- QR code on every page footer — scan to verify authenticity
- Verify endpoint: GET /reports/verify/:reportId

Report engine: MP-012-pdf-v7

SAMPLE FILES
------------
sample-v7.pdf  — Jonathan, 3 journeys, 46.8 miles
empty-v7.pdf   — No journeys (empty state)
large-v7.pdf   — Stress test: 1,234.6 miles
